<footer class="footer">
    &copy; <?php echo date('Y'); ?> Værchatbot-chatbot | IS115 | Sara og Oda
</footer>
</body>
</html>